

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `passsword` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO admin VALUES("1","admin@admin.com","admin@123");



CREATE TABLE `bank` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `name_on_card` varchar(30) NOT NULL,
  `credit_card_no` varchar(12) NOT NULL,
  `exp_month` varchar(15) NOT NULL,
  `exp_year` year(4) NOT NULL,
  `CVV` int(3) NOT NULL,
  `rider_id` int(11) NOT NULL,
  `req_id` int(11) NOT NULL,
  `Dtime` datetime NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`trans_id`),
  KEY `driver_id` (`driver_id`),
  KEY `rider_id` (`rider_id`),
  KEY `req_id` (`req_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO bank VALUES("1","0","kkkkkkkkkkkkkkkkkkkk","1111-2222-33","march","2019","345","27","53","0000-00-00 00:00:00","250");
INSERT INTO bank VALUES("2","0","dddddddddddddddddddd","111111111111","sssssssssss","0000","222","27","53","0000-00-00 00:00:00","250");



CREATE TABLE `distance` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `distance` decimal(11,5) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO distance VALUES("8","panachippara","edamaruk","88.00000");
INSERT INTO distance VALUES("9","panachippara","melukkavu","14.00000");
INSERT INTO distance VALUES("27","test","test","10.00000");
INSERT INTO distance VALUES("11","panachippara","muttom","24.00000");
INSERT INTO distance VALUES("12","panachippara","amparanirappel","4.00000");
INSERT INTO distance VALUES("13","panachippara","edappady","11.00000");
INSERT INTO distance VALUES("14","panachippara","chemmalamattom","9.00000");
INSERT INTO distance VALUES("15","panachippara","thidanad","6.00000");
INSERT INTO distance VALUES("16","panachippara","pinakkanad","10.00000");
INSERT INTO distance VALUES("17","panachippara","bharanaganam","9.00000");
INSERT INTO distance VALUES("18","panachippara","kalakketty","11.00000");
INSERT INTO distance VALUES("19","panachippara","kappadu","13.00000");
INSERT INTO distance VALUES("20","panachippara","anakkal","14.00000");
INSERT INTO distance VALUES("21","panachippara","thodupuzha","32.00000");
INSERT INTO distance VALUES("22","erattupetta","poonajr","2.00000");
INSERT INTO distance VALUES("23","erattupetta","edamaruk","6.00000");
INSERT INTO distance VALUES("24","erattupetta","melukkavu","12.00000");
INSERT INTO distance VALUES("25","erattupetta","muttom","21.60000");
INSERT INTO distance VALUES("26","erattupetta","amparanirappel","1.60000");



CREATE TABLE `driveraccount` (
  `dic` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `housename` varchar(20) NOT NULL,
  `place` varchar(20) NOT NULL,
  `district` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `cardno` varchar(12) NOT NULL,
  `month` varchar(15) NOT NULL,
  `year` year(4) NOT NULL,
  `CW` int(4) NOT NULL,
  PRIMARY KEY (`dic`),
  KEY `driver_id` (`driver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO driveraccount VALUES("1","82","ddddddddddd","tttttttt","ttttttttt","tttt","111111111111","january","0000","77");
INSERT INTO driveraccount VALUES("2","85","","","","","","","0000","0");
INSERT INTO driveraccount VALUES("3","90","","","","","","","0000","0");
INSERT INTO driveraccount VALUES("4","91","","","","","","","0000","0");



CREATE TABLE `driverdetails` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(15) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `vehicle_name` varchar(30) NOT NULL,
  `vehicle_no` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `phoneno` int(10) NOT NULL,
  `category` int(11) NOT NULL COMMENT 'category he belongs',
  `status` int(11) NOT NULL COMMENT 'whether he is available or not',
  `O_N` int(11) NOT NULL,
  `no_of_rides` int(11) NOT NULL,
  PRIMARY KEY (`driver_id`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

INSERT INTO driverdetails VALUES("1","Kripa","Mary","Jose","kripa@gmail.com","kripa@gmail.com","Erattupetta","","0","2","2147483647","0","1","0","0");
INSERT INTO driverdetails VALUES("2","Lighiya","7777777777","ddddddddd","jhjk@gmail.com","Lqwert12","Erattupetta","","0","1","2147483647","0","1","0","0");
INSERT INTO driverdetails VALUES("3","Rani","","Jose","Rani@gmail.com","Ranioff@55","Pala","","0","1","1234567898","0","0","0","0");
INSERT INTO driverdetails VALUES("4","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("5","Kripa","Mary","Jose","kripa@gmail.com","Kripamary@55","pala","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("6","Kripa","Mary","Jose","kripa@gmail.com","K1234qwert","edf","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("7","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("8","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("9","","","","","","","","0","1","0","1","0","0","0");
INSERT INTO driverdetails VALUES("10","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("11","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("12","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("13","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("14","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("15","Abraham","","Jose","Aby@gmail.com","Aby@12qwer","Erattupetta","","0","1","2147483647","1","0","0","0");
INSERT INTO driverdetails VALUES("16","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("17","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("18","Abrahamkrrr","","Jose","Aby@gmail.com","Aby@12qwer","erattupetta","","0","2","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("19","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("20","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("21","Tbaitha","","jose","tabi@gmail.com","Tabi@12qwe","panachippara","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("22","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("23","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("24","Tbaitha","","jose","tabi@gmail.com","Qwerty@13","poonjar","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("25","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("26","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("27","Abraham","","Jose","Aby@gmail.com","Qwert@12","pala","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("28","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("29","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("30","Tbaitha","","jose","tabi@gmail.com","Tabi@12qwer","pala","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("31","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("32","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("33","Tbaitha","","jose","tabi@gmail.com","Qwert12qwer","dfdgdg","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("34","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("35","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("36","Abrahamkrrr","","Jose","Aby@gmail.com","Qwert12rty","kottayam","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("37","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("38","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("39","Abrahamkrrr","","Jose","Aby@gmail.com","Abyqwer@12","pala","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("40","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("41","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("42","Abrahamkrrr","","Jose","Aby@gmail.com","Qweert123344","mkkkk","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("43","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("44","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("45","Abrahamkrrr","","Jose","Aby@gmail.com","Qwee12234234","ghh","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("46","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("47","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("48","Abraham","","Jose","Aby@gmail.com","Qweer1343w25","bbb","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("49","","","","","","","","0","0","0","1","0","0","0");
INSERT INTO driverdetails VALUES("50","Abraham","","Jose","Aby@gmail.com","Errdtrddr1111111","33","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("51","","","","","","","","0","0","0","2","0","0","0");
INSERT INTO driverdetails VALUES("52","Kiran","","JOSe","jacab@123","JAsdf123","nlml;l","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("53","","","","","","","","0","0","0","2","0","0","0");
INSERT INTO driverdetails VALUES("54","","","","","","","","0","0","0","2","0","0","0");
INSERT INTO driverdetails VALUES("55","Kiran","","JOSe","jacab@123","Qwer123433","kjkjbjkbjkbkjb","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("56","Kiran","","JOSe","jacab@123","Qwer1234kjbb","  nmmn n n ","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("57","Jacob","","Jose","Jasmin@gmail.com","Aqwert123","Kottayam","","0","0","2147483647","2","0","0","0");
INSERT INTO driverdetails VALUES("58","","","","","","","","0","0","0","2","0","0","0");
INSERT INTO driverdetails VALUES("59","Jacob","","Jose","Jasmin@gmail.com","Qwerty1234","hfgfhfj","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("60","Jacob","","Jose","Jasmin@gmail.com","Qwert1234","nkjnjkjnjn","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("61","Jacob","","Jose","Jasmin@gmail.com","Qtyuio111111111","ddddddd","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("62","Jacob","","Jose","Jasmin@gmail.com","Qwerty12345","dddddddddd","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("63","Jacob","","Jose","Jasmin@gmail.com","Aqwert1234","mmmmmmmmmmmm","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("64","Jacob","","Jose","Jasmin@gmail.com","Qwert1234","erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("65","kerthi","","sureesh","kerthi@gmail.com","Kerthi@123","erattupetta","","0","0","2147483647","1","0","0","0");
INSERT INTO driverdetails VALUES("66","Anu","","jose","anu@gmail.com","Anu@123qw","dddddd","","0","0","2147483647","2","0","0","0");
INSERT INTO driverdetails VALUES("67","Hey","","njan","anu@gmail.com","Hey@12345eee","uj","dddddddddd","2147483647","1","2147483647","1","1","0","0");
INSERT INTO driverdetails VALUES("68","Hey","","njan","anu@gmail.com","Juyuy123","dc","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("69","Anu","","jose","anu@gmail.com","K234ghghj","ggggggggggggg","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("70","Anu","","jose","anu@gmail.com","Hg12tghhhh","hhhhhhhhhhh","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("71","Anu","","jose","anu@gmail.com","Jhhh22222","ddddddddd","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("72","Hey","","njan","anu@gmail.com","JHghh123","rrrrrrrrr","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("73","Anu","","jose","anu@gmail.com","Jhj12344","ggggggggggg","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("74","Hey","","njan","anu@gmail.com","Hgj12234","gggggggggg","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("75","Hey","","njan","anu@gmail.com","12HGHyyyyyy","ooooooooooo","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("76","Rajamani","tyyyyynnnn","mani","taf@gmail.com","","hhhhhhhhhh","vkdfnvkdfn","2147483647","1","2147483647","1","1","0","0");
INSERT INTO driverdetails VALUES("77","Hey","","njan","anu@gmail.com","Kjdfjb1323","mv","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("78","Rajamani","","mani","taf@gmail.com","Jhhh1223","ttttttt","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("79","Joe","John","Vincy","Joe@gmail.com","Joe@12jjj","llllllllll","dddddddddd","1111111111","1","2147483647","1","1","0","0");
INSERT INTO driverdetails VALUES("80","josemonnndbgfjb","bfg","fgb","jose@gmail.com","Josd12Jvjvj","kkkkkkk","rgthytyht","677777","1","2147483647","1","1","0","0");
INSERT INTO driverdetails VALUES("81","Unni","","john","john@gmail.com","Unni@1234","Erattupetta","dddddddddd","2147483647","1","2147483647","1","1","0","0");
INSERT INTO driverdetails VALUES("82","Joe","John","Vincy","Unni@gmail.com","Joejohn@12","Erattupetta","dddddddddd","2147483647","3","2147483647","1","1","1","0");
INSERT INTO driverdetails VALUES("83","Ajay","","Isac","ajay@gmail.com","AjayIsac1","Erattupetta","dddddddddd","2147483647","3","0","2","1","1","0");
INSERT INTO driverdetails VALUES("84","Joe","John","Vincy","Unni@gmail.com","Kripa@12","Erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("85","Kiran","ffffffff","","Unni@gmail.com","Kripa@12","Erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("86","Kiran","ffffffff","","Unni@gmail.com","Kiran@12","erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("87","Ajay","","Isac","ajay@gmail.com","Kiran@12","erattupetta","","0","0","0","0","0","0","0");
INSERT INTO driverdetails VALUES("88","Ajay","","Isac","ajay@gmail.com","Kiran@12","ffhjgj","","0","0","0","0","0","0","0");
INSERT INTO driverdetails VALUES("89","Kiran","ffffffff","","Unni@gmail.com","Kiran@12","erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("90","Kiran","ffffffff","","john@gmail.com","Kiran@12","erattupetta","","0","0","2147483647","0","1","0","0");
INSERT INTO driverdetails VALUES("91","Kiran","","","josekripamary99@gmail.com","Kiran@12","Erattupetta","","0","0","2147483647","0","0","0","0");
INSERT INTO driverdetails VALUES("92","Kripa","Mary","Jose","josekripamary99@gmail.com","Kiran@12","Erattupetta","nnnnnnnnnnnnnn","2147483647","3","2147483647","1","1","0","0");



CREATE TABLE `driverdocuments` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `photo` varchar(30) NOT NULL,
  `licence` varchar(30) NOT NULL,
  `registration` varchar(30) NOT NULL,
  `insurance` varchar(30) NOT NULL,
  `permit` varchar(30) NOT NULL,
  PRIMARY KEY (`did`),
  KEY `driver_id` (`driver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO driverdocuments VALUES("20","76","IMG_20180714_203539_930.jpg","","","","");
INSERT INTO driverdocuments VALUES("19","76","IMG_20180714_203539_930.jpg","","","","");
INSERT INTO driverdocuments VALUES("18","76","images (6).jpg","","","","");
INSERT INTO driverdocuments VALUES("17","76","download.jpg","","","","");
INSERT INTO driverdocuments VALUES("16","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("15","76","download (3).jpg","","","","");
INSERT INTO driverdocuments VALUES("14","76","IMG_20180714_203539_930.jpg","","","","");
INSERT INTO driverdocuments VALUES("13","76","IMG_20180714_203539_930.jpg","","","","");
INSERT INTO driverdocuments VALUES("12","67","","Free_Sample_By_Wix (1).jpg","","","");
INSERT INTO driverdocuments VALUES("11","67","Drive to Heavens, Central Prov","","","","");
INSERT INTO driverdocuments VALUES("21","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("22","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("23","76","download.jpg","","","","");
INSERT INTO driverdocuments VALUES("24","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("25","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("26","76","download (3).jpg","","","","");
INSERT INTO driverdocuments VALUES("27","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("28","76","download.jpg","","","","");
INSERT INTO driverdocuments VALUES("29","76","download (1).jpg","","","","");
INSERT INTO driverdocuments VALUES("30","76","download.jpg","","","","");
INSERT INTO driverdocuments VALUES("31","80","download.jpg","","","","");
INSERT INTO driverdocuments VALUES("32","81","download (3).jpg","","","","");
INSERT INTO driverdocuments VALUES("33","82","IMG_20180714_203539_930.jpg","","","","");
INSERT INTO driverdocuments VALUES("34","83","images (6).jpg","","","","");
INSERT INTO driverdocuments VALUES("35","82","images (6).jpg","","","","");



CREATE TABLE `driverlogin` (
  `dlogin_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  PRIMARY KEY (`dlogin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO driverlogin VALUES("1","1","kripa@gmail.com","kripa@gm");
INSERT INTO driverlogin VALUES("2","2","jhjk@gmail.com","Lqwert12");
INSERT INTO driverlogin VALUES("3","3","Rani@gmail.com","Ranioff@");
INSERT INTO driverlogin VALUES("4","15","Aby@gmail.com","Aby@12qw");



CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `driverprofileview` AS select `driverdetails`.`driver_id` AS `driver_id`,`driverdetails`.`fname` AS `fname`,`driverdetails`.`lname` AS `lname`,`driverdetails`.`mname` AS `mname`,`driverdetails`.`phoneno` AS `phoneno`,`driverdetails`.`vehicle_name` AS `vehicle_name`,`driverdetails`.`vehicle_no` AS `vehicle_no`,`driverdocuments`.`did` AS `did`,`driverdocuments`.`photo` AS `photo` from (`driverdetails` join `driverdocuments`) where (`driverdetails`.`driver_id` = `driverdocuments`.`driver_id`);

INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","20","IMG_20180714_203539_930.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","19","IMG_20180714_203539_930.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","18","images (6).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","17","download.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","16","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","15","download (3).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","14","IMG_20180714_203539_930.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","13","IMG_20180714_203539_930.jpg");
INSERT INTO driverprofileview VALUES("67","Hey","njan","","2147483647","dddddddddd","2147483647","12","");
INSERT INTO driverprofileview VALUES("67","Hey","njan","","2147483647","dddddddddd","2147483647","11","Drive to Heavens, Central Prov");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","21","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","22","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","23","download.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","24","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","25","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","26","download (3).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","27","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","28","download.jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","29","download (1).jpg");
INSERT INTO driverprofileview VALUES("76","Rajamani","mani","tyyyyynnnn","2147483647","vkdfnvkdfn","2147483647","30","download.jpg");
INSERT INTO driverprofileview VALUES("80","josemonnndbgfjb","fgb","bfg","2147483647","rgthytyht","677777","31","download.jpg");
INSERT INTO driverprofileview VALUES("81","Unni","john","","2147483647","dddddddddd","2147483647","32","download (3).jpg");
INSERT INTO driverprofileview VALUES("82","Joe","Vincy","John","2147483647","dddddddddd","2147483647","33","IMG_20180714_203539_930.jpg");
INSERT INTO driverprofileview VALUES("83","Ajay","Isac","","0","dddddddddd","2147483647","34","images (6).jpg");
INSERT INTO driverprofileview VALUES("82","Joe","Vincy","John","2147483647","dddddddddd","2147483647","35","images (6).jpg");



CREATE TABLE `fare` (
  `fare_id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL,
  `min_charge` int(11) NOT NULL,
  `cpk` int(11) NOT NULL,
  `wtg_charge` int(11) NOT NULL,
  PRIMARY KEY (`fare_id`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO fare VALUES("9","9","9","9","9");
INSERT INTO fare VALUES("2","2","30","3","150");
INSERT INTO fare VALUES("3","3","300","50","100");



CREATE TABLE `payment` (
  `pay_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  KEY `trans_id` (`trans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




CREATE TABLE `rating` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `rider_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `driver_id` (`driver_id`),
  KEY `rider_id` (`rider_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `rider_id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `source` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `total_amt` int(11) NOT NULL,
  `DateT` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`req_id`),
  KEY `driver_id` (`driver_id`),
  KEY `rider_id` (`rider_id`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO request VALUES("1","0","27","0","pala","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("2","0","27","0","pala","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("3","0","27","0","pala","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("4","0","27","0","pla","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("5","0","27","0","erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("6","0","27","0","pala","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("7","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("8","0","27","0","Erattpetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("9","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("10","0","27","0","erattipetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("11","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("12","0","27","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("13","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("14","0","27","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("15","0","27","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("16","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("17","0","27","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("18","0","27","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("19","0","28","0","Erattupetta","pala","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("20","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("21","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("22","0","28","0","Erattupetta","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("23","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("24","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("25","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("26","0","28","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("27","0","27","0","Erattupetta","kera","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("28","0","27","0","Erattupetta","kera","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("29","0","27","0","Erattupetta","erattupetta","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("30","0","27","0","Erattupetta","ramapuram","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("31","0","27","0","Erattupetta","nn","0","0000-00-00 00:00:00","0");
INSERT INTO request VALUES("32","0","27","2","Erattupetta","ramapuram","0","2019-09-22 19:11:13","0");
INSERT INTO request VALUES("33","0","27","2","Erattupetta","ramapuram","0","2019-09-22 19:13:40","0");
INSERT INTO request VALUES("34","0","27","2","Erattupetta","kera","0","2019-09-22 19:22:59","0");
INSERT INTO request VALUES("35","0","27","2","Erattupetta","ramapuram","0","2019-09-22 19:23:54","0");
INSERT INTO request VALUES("36","0","27","4","Erattupetta","ramapuram","0","2019-09-23 05:51:16","0");
INSERT INTO request VALUES("37","0","27","4","Erattupetta","ramapuram","0","2019-09-23 06:19:54","0");
INSERT INTO request VALUES("38","0","27","3","Erattupetta","pala","0","2019-09-23 13:29:47","0");
INSERT INTO request VALUES("39","0","27","3","Erattupetta","pala","0","2019-09-23 13:43:05","0");
INSERT INTO request VALUES("40","0","27","3","Erattupetta","pala","0","2019-09-23 17:18:14","0");
INSERT INTO request VALUES("41","0","27","3","Erattupetta","pala","0","2019-09-23 17:20:14","0");
INSERT INTO request VALUES("42","0","27","3","Erattupetta","pala","0","2019-09-24 14:56:45","0");
INSERT INTO request VALUES("43","0","27","3","Erattupetta","pala","0","2019-09-24 14:57:07","0");
INSERT INTO request VALUES("44","0","27","3","Erattupetta","pala","0","2019-09-24 15:18:43","0");
INSERT INTO request VALUES("45","0","27","3","Erattupetta","ramapuram","0","2019-09-24 15:20:07","0");
INSERT INTO request VALUES("46","0","27","0","Erattupetta","pala","0","2019-09-24 15:21:33","0");
INSERT INTO request VALUES("47","0","27","3","Erattupetta","ramapuram","0","2019-09-24 15:32:17","-1");
INSERT INTO request VALUES("48","0","27","2","erattupetta","poonjar","0","2019-09-29 18:15:34","0");
INSERT INTO request VALUES("49","0","27","2","Erattupetta","ramapuram","0","2019-10-05 14:48:02","0");
INSERT INTO request VALUES("50","0","27","2","Erattupetta","nkknk","0","2019-10-05 15:02:31","0");
INSERT INTO request VALUES("51","0","27","2","Erattupetta","nkknk","0","2019-10-05 15:03:36","0");
INSERT INTO request VALUES("52","0","27","0","Erattupetta","ramapuram","0","2019-10-05 17:02:48","0");
INSERT INTO request VALUES("53","0","27","3","Erattupetta","ramapuram","250","2019-10-05 17:03:28","-1");
INSERT INTO request VALUES("54","0","27","3","Erattupetta","ramapuram","250","2019-10-05 17:25:56","0");
INSERT INTO request VALUES("55","0","1","0","panachippara","poonjar","0","2019-10-07 12:17:52","0");
INSERT INTO request VALUES("56","0","1","0","panachippara","poonjar","0","2019-10-07 12:22:16","0");



CREATE TABLE `riderdetails` (
  `rider_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(15) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(8) NOT NULL,
  `phoneno` int(10) NOT NULL,
  PRIMARY KEY (`rider_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO riderdetails VALUES("1","Daniel","","Jose","daniel@gmail.com","Daniel@1","2147483647");
INSERT INTO riderdetails VALUES("2","Daniel","","Jose","daniel@gmail.com","Daniel@1","2147483647");
INSERT INTO riderdetails VALUES("3","Dalvy","","Jose","dalvy@gmail.com","Dalvy@12","2147483647");
INSERT INTO riderdetails VALUES("4","Liya","","george","liya@gmail.com","Liya@123","2147483647");
INSERT INTO riderdetails VALUES("5","Joe","John","Vincy","joe@gmail.com","Joe@123q","2147483647");
INSERT INTO riderdetails VALUES("6","Rahul","","htyt","rahul@gmail.com","Rahul@7q","2147483647");
INSERT INTO riderdetails VALUES("7","Krip","","mARY","kripa@gmail.com","Kripa@89","666666");
INSERT INTO riderdetails VALUES("8","Unni","","kuttan","unni@gmail.com","Unni@123","66666");
INSERT INTO riderdetails VALUES("9","Karthika","","rajev","karthu@gmail.com","Karthu@1","2147483647");
INSERT INTO riderdetails VALUES("10","Kinginigtgg","","ggg","kingu@gmail.com","Kingu@12","666666");
INSERT INTO riderdetails VALUES("11","Kinginigtgg","","ggg","kingu@gmail.com","Kingu@12","666666");
INSERT INTO riderdetails VALUES("15","Preetha ","","rose","preetha@gmail.com","Preetha@","1223234567");
INSERT INTO riderdetails VALUES("13","reena","","Jose","reena@gmail.com","Reena@12","2147483647");
INSERT INTO riderdetails VALUES("14","reena","","Jose","reena@gmail.com","Reena@24","2147483647");
INSERT INTO riderdetails VALUES("16","George","","njaral","george@gmail.com","George@1","2147483647");
INSERT INTO riderdetails VALUES("17","Tabitha","","jose","tabitha@gmail.com","Tabitha@","2147483647");
INSERT INTO riderdetails VALUES("18","rtyu","","rtyu","rtyu@gmail.com","Rtyu@123","5678");
INSERT INTO riderdetails VALUES("19","Suz","","jose","suz@gmail.com","Suz@123q","12");
INSERT INTO riderdetails VALUES("20","rajama","","pk","rajama@gmail.com","Rajama@p","2147483647");
INSERT INTO riderdetails VALUES("21","Joel","","Jose","joel@gmail.com","Joel@123","8888");
INSERT INTO riderdetails VALUES("22","rrrrrrrrr","fggtg","sunny","gbgbggbgbgbbgb","44gfvg","0");
INSERT INTO riderdetails VALUES("23","mlkjkljk","bfg","fghfg","jose@gmail.com","12@Jkkjf","66666");
INSERT INTO riderdetails VALUES("24","jkj","uuuuuu","uuuuuuu","ktyui@gmail.com","12@mahfk","777777777");
INSERT INTO riderdetails VALUES("25","Rexi","","Jose","rexi@gmail.com","Rexi@123","123456789");
INSERT INTO riderdetails VALUES("26","Ajay","","Isac","Isac@gmail.com","Ajay@123","2147483647");
INSERT INTO riderdetails VALUES("27","Kiran","treesa","jose","kiran@gmail.com","Kiran@12","1234567890");
INSERT INTO riderdetails VALUES("28","sre","","raj","sre@gmail.com","Sreyas@1","88888888");



CREATE TABLE `riderlogin` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `rider_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`login_id`),
  KEY `rider_id` (`rider_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO riderlogin VALUES("1","18","rtyu@gmail.com","Rtyu@123");
INSERT INTO riderlogin VALUES("2","19","suz@gmail.com","Suz@123q");
INSERT INTO riderlogin VALUES("3","21","joel@gmail.com","Joel@123");
INSERT INTO riderlogin VALUES("4","21","joel@gmail.com","Joel@123");
INSERT INTO riderlogin VALUES("5","21","joel@gmail.com","Joel@123");
INSERT INTO riderlogin VALUES("6","21","joel@gmail.com","Joel@123");
INSERT INTO riderlogin VALUES("7","22","ritto@gmail.com","Ritto@12");
INSERT INTO riderlogin VALUES("8","26","Isac@gmail.com","Ajay@123");
INSERT INTO riderlogin VALUES("9","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("10","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("11","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("12","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("13","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("14","28","sre@gmail.com","Sreyas@1");
INSERT INTO riderlogin VALUES("15","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("16","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("17","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("18","27","kiran@gmail.com","kiran@12");
INSERT INTO riderlogin VALUES("19","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("20","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("21","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("22","27","kiran@gmail.com","Kiran@12");
INSERT INTO riderlogin VALUES("23","1","daniel@gmail.com","Daniel@1");



CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;




CREATE TABLE `vehicle` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `cc` int(11) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO vehicle VALUES("1","auto","140");
INSERT INTO vehicle VALUES("2","motorcycle","500");
INSERT INTO vehicle VALUES("3","suv","2500");
INSERT INTO vehicle VALUES("4","hatchback","1400");
INSERT INTO vehicle VALUES("7","sedan","1000");

