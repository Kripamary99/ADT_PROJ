<?php 
 require 'config.php';  
 $query ="SELECT * FROM distance";  
 $result = mysqli_query($con, $query);  
  
?>

<!DOCTYPE html>
<html>

<head>
<style type="text/css">
        body{
          display: table;
          width: 100%;
          background: #dedede;
          text-align: center;
        }
        *{ 
          -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
          -moz-box-sizing: border-box;    /* Firefox, other Gecko */
          box-sizing: border-box;         /* Opera/IE 8+ */
        }

        .aa_h2{
          font:100 5rem/1 Roboto;
          text-transform: uppercase;
        }
        table{
           background: #fff;
        }
        table,thead,tbody,tfoot,tr, td,th{
          text-align: center;
          margin: auto;
          border:1px solid #dedede;
          padding: 1rem;
          width: 50%;
        }
        .table    { display: table; width: 50%; }
        .tr       { display: table-row;  }
        .thead    { display: table-header-group }
        .tbody    { display: table-row-group }
        .tfoot    { display: table-footer-group }
        .col      { display: table-column }
        .colgroup { display: table-column-group }
        .td, .th   { display: table-cell; width: 50%; }
        .caption  { display: table-caption }

        .table,
        .thead,
        .tbody,
        .tfoot,
        .tr,
        .td,
        .th{
          text-align: center;
          margin: auto;
          padding: 1rem;
        }
        .table{
          background: #fff;
          margin: auto;
          border:none;
          padding: 0;
          margin-bottom: 5rem;
        }

        .th{
          font-weight: 700;
          border:1px solid #dedede;
          &:nth-child(odd){
            border-right:none;
          }
        }
        .td{
          font-weight: 300;
          border:1px solid #dedede;
          border-top:none;
          &:nth-child(odd){
            border-right:none;
          }
        }

        .aa_htmlTable{
          background: #00ffff;
          padding: 5rem;
          display: table;
          width: 100%;
          height: 100vh;
          vertical-align: middle;
        }
        .aa_css{
          background: skyblue;
          padding: 5rem;
          display: table;
          width: 100%;
          height: 100vh;
          vertical-align: middle;
        }

        .aa_ahmadawais{
          display: table;
          width: 100%;
          font: 100 1.2rem/2 Roboto;
          margin: 5rem auto;
        }

  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Admin</title>
  <!-- Favicon -->
  <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="../assets/css/argon.css?v=1.0.0" rel="stylesheet">


</head>

<body>
  <!-- Sidenav -->
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="../index.html">
        <img src="../assets/img/brand/blue.png" class="navbar-brand-img" alt="...">
      </a>
      
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="../index.html">
                <img src="../assets/img/brand/blue.png">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        <!-- Form -->
        <form class="mt-4 mb-3 d-md-none">
          <div class="input-group input-group-rounded input-group-merge">
            <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Search" aria-label="Search">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <span class="fa fa-search"></span>
              </div>
            </div>
          </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/fare.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Fare
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/distance.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Distance
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/vehicle.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Vehicle
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/view_bank.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Bank Details
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_documents.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Documents
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_login.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Login
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_request_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Request Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_rider_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Rider Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_rider_login.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Rider login
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="mysqli.php">
              <i class="ni ni-key-25 text-info"></i>Database Backup
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="ni ni-circle-08 text-pink"></i> Logout
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
      
        
        
      </div>
    </nav>
    

<div class="aa_htmlTable">
  
  <table>
    <thead>
      <tr>
        <th>DID</th>
        <th>SOURCE</th>
        <th>DESTINATION</th>
        <th>DISTANCE</th>
      </tr>
    </thead>
    <tbody>
<?php  
  while($row = mysqli_fetch_array($result))  
  {  
  ?>  
      <tr>

                <td><?php echo $row['did']; ?></td>
                <td><?php echo $row['source'];?></td>  
                <td><?php echo $row['destination']; ?></td>
                <td><?php echo $row['distance']; ?></td>
      </tr>
<?php     }        ?>       
  </table>
</div>
     <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2019 <a href="#" class="font-weight-bold ml-1" target="_blank"></a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link" target="_blank"></a>
              </li>
              
              
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/clipboard/dist/clipboard.min.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.0.0"></script>
</body>

</html>