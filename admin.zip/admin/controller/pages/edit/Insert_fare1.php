<?php
include("config.php");

	$fare_id=$_POST['fare_id'];
	$vid=$_POST['vid'];
	$min_charge=$_POST['min_charge'];
	$cpk=$_POST['cpk'];
	$wtg_charge=$_POST['wtg_charge'];
$query="INSERT INTO fare values($fare_id,$vid,$min_charge,$cpk,$wtg_charge)";
$exec=mysqli_query($conn  , $query);
	

	
if(!$exec)
{
	echo "<script>alert('Not inserted')</script>";
}
echo "<script>alert('Successfull')</script>";
header('Location:../fare.php');

include("Insert_fare.php");
?>