<?php 
session_start();
ob_start(); 
require ('config.php');
$id = $_SESSION['id'];
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$vid=$_POST['vid'];
  	$type=$_POST['type'];
  	$cc=$_POST['cc'];

	$update="UPDATE vehicle set vid=$vid,type='$type',cc=$cc where vid=$vid";
	mysqli_query($conn,$update);
	header('Location:../vehicle.php');
}



/*$query = "INSERT INTO `bus_driver`(`id`, `name`, `phonenumber`, `busnumber`, `place`) VALUES ('','$drivername','$phname','$busnumber','$place')";
$result_query = mysqli_query($con, $query);
echo '<script>alert("Details Entered"); location.replace(document.referrer);</script>';*/
?>