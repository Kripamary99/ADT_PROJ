<?php
include("config.php");

	$type=$_POST['type'];
	$cc=$_POST['cc'];
	
$query="INSERT INTO `vehicle`(`vid`, `type`, `cc`) VALUES ('','$type','$cc')";
$exec=mysqli_query($conn  , $query);
	

	
if(!$exec)
{
	echo "<script>alert('Not inserted')</script>";
}
echo "<script>alert('Successfull')</script>";
header('Location:../vehicle.php');

include("Insert_distance.php");
?>