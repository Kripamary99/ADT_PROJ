<?php 
session_start();
ob_start(); 
require ('config.php');
$id = $_SESSION['id'];
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$did=$_POST['did'];
  	$source=$_POST['source'];
  	$destination=$_POST['destination'];
  	$distance=$_POST['distance'];

	$update="UPDATE distance set did=$did,source='$source',destination='$destination',distance=$distance where did=$did";
	mysqli_query($conn,$update);
	header('Location:../distance.php');
}



/*$query = "INSERT INTO `bus_driver`(`id`, `name`, `phonenumber`, `busnumber`, `place`) VALUES ('','$drivername','$phname','$busnumber','$place')";
$result_query = mysqli_query($con, $query);
echo '<script>alert("Details Entered"); location.replace(document.referrer);</script>';*/
?>