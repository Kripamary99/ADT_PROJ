<?php
require 'config.php';  
session_start();
 if(isset($_GET['edit_id'])){

    $id=mysqli_real_escape_string($conn,$_GET['edit_id']); 
    $query="SELECT * from vehicle where vid='$id'";
    $result=mysqli_query($conn,$query);
    $row = mysqli_fetch_array($result);
    $_SESSION['id'] = $id;
  }
 else{
 		echo '<script>alert("Inavalid Action"); location.replace(document.referrer);</script>';

  }
 ?>  
<!DOCTYPE html>
<html lang="en">
<head>
	<script>
			function myFunction() {
    			alert("Details Updated");
			}
		</script>
	<title>Edit Details</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--=============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--=============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--=============================================================================================-->
</head>
<body>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" method = "post" action="update_vehicle1.php">
				<span class="contact100-form-title">
					Edit Details
				</span>
				VID
				<div class="wrap-input100 validate-input" >
					<input class="input100" type="number" value="<?php echo $row['vid'];  ?>" name="vid" placeholder="Fare ID">
					<span class="focus-input100"></span>
				</div>
				TYPE
				<div class="wrap-input100 validate-input" >
					<input class="input100" type="text" value="<?php echo $row['type'];  ?>" name="type" placeholder="VID">
					<span class="focus-input100"></span>
				</div>
				CC
				<div class="wrap-input100 validate-input" >
					<input class="input100" type="text" value="<?php echo $row['cc'];  ?>" name="cc" placeholder="Minimum Charge">
					<span class="focus-input100"></span>
				</div>
				
				

				<!--<div class="wrap-input100 validate-input" >
					<input class="input100" type="text" name="phone" placeholder="Phone" >
					<span class="focus-input100"></span>
				</div>-->
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" onclick="myFunction()">
						<span>
							<i class="fa fa-paper-plane-o m-r-6" aria-hidden="true"></i>
							Update Details
						</span>
					</button>
				</div>
			</form>
		</div>
	</div>
	<div id="dropDownSelect1"></div>

<!--=============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--=============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--=============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--=============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--=============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--=============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--=============================================================================================-->
	<script src="js/main.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-23581568-13');
</script>
</body>
</html>