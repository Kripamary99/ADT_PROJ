<?php
include("config.php");

	$source=$_POST['source'];
	$destination=$_POST['destination'];
	$distance=$_POST['distance'];
	
$query="INSERT INTO `distance`(`did`, `source`, `destination`, `distance`) VALUES ('','$source','$destination','$distance')";
$exec=mysqli_query($conn  , $query);
	

	
if(!$exec)
{
	echo "<script>alert('Not inserted')</script>";
}
echo "<script>alert('Successfull')</script>";
header('Location:../distance.php');

include("Insert_distance.php");
?>