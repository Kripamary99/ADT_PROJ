<?php 
session_start();
ob_start(); 
require ('config.php');
$id = $_SESSION['id'];
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$fare_id=$_POST['fare_id'];
  	$vid=$_POST['vid'];
  	$min_charge=$_POST['min_charge'];
  	$wtg_charge=$_POST['wtg_charge'];
  	$cpk =$_POST['cpk'];

	$update="UPDATE fare set fare_id=$fare_id,vid=$vid,min_charge=$min_charge,cpk=$cpk,wtg_charge=$wtg_charge where fare_id=$fare_id";
	mysqli_query($conn,$update);
	header('Location:../fare.php');
}



/*$query = "INSERT INTO `bus_driver`(`id`, `name`, `phonenumber`, `busnumber`, `place`) VALUES ('','$drivername','$phname','$busnumber','$place')";
$result_query = mysqli_query($con, $query);
echo '<script>alert("Details Entered"); location.replace(document.referrer);</script>';*/
?>