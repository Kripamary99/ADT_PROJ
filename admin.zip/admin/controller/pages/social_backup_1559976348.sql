

CREATE TABLE `active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;




CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO admin VALUES("1","admin@admin.com","admin");



CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_body` text NOT NULL,
  `posted_by` varchar(60) NOT NULL,
  `posted_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `removed` varchar(3) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO comments VALUES("1","haha","abhiram_das_1_2","vijina_aa","2019-05-02 17:02:39","no","3");
INSERT INTO comments VALUES("2","hi","abhiram_das_1_2","vijina_aa","2019-05-02 17:24:13","no","3");
INSERT INTO comments VALUES("3","hi","vijina_aa","abhiram_das_1_2","2019-05-03 14:49:36","no","2");
INSERT INTO comments VALUES("4","hi","abhiram_das_1_2","vijina_aa","2019-05-04 07:12:07","no","1");



CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO friend_requests VALUES("2","abhiram_das","aa_ss");
INSERT INTO friend_requests VALUES("3","akhil_ashok","vijina_aa");



CREATE TABLE `likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO likes VALUES("1","","0");
INSERT INTO likes VALUES("7","vijina_aa","0");
INSERT INTO likes VALUES("13","abhiram_das_1_2","2");



CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL,
  `body` text NOT NULL,
  `date` datetime NOT NULL,
  `opened` varchar(3) NOT NULL,
  `viewed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO messages VALUES("1","abhiram_das","vijina_aa","da","2019-03-11 14:41:14","yes","yes","no");
INSERT INTO messages VALUES("2","abhiram_das","akhil_ashok","hoooooyyyy","2019-03-11 14:59:38","no","yes","no");
INSERT INTO messages VALUES("3","vijina_aa","abhiram_das","hai","2019-03-15 07:41:28","yes","yes","no");
INSERT INTO messages VALUES("4","abhiram_das_1","abhiram_das_1","hii","2019-03-15 07:54:35","yes","no","no");
INSERT INTO messages VALUES("5","vijina_aa","abhiram_das_1","hi","2019-03-15 07:58:58","no","yes","no");
INSERT INTO messages VALUES("6","abhiram_das","vijina_aa","hi","2019-03-16 04:28:54","yes","yes","no");
INSERT INTO messages VALUES("8","vijina_aa","abhiram_das","hi","2019-03-16 04:37:35","yes","yes","no");
INSERT INTO messages VALUES("9","abhiram_das","vijina_aa","hi","2019-03-16 04:42:06","no","yes","no");
INSERT INTO messages VALUES("10","abhiram_das","vijina_aa","hello","2019-05-03 16:03:26","no","yes","no");



CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_to` varchar(50) NOT NULL,
  `user_from` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `opened` varchar(3) NOT NULL,
  `viewed` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO notifications VALUES("1","","vijina_aa","Vijina Aa liked your post","post.php?id=","2019-05-03 15:06:22","no","yes");
INSERT INTO notifications VALUES("2","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=2","2019-05-04 06:01:23","no","no");
INSERT INTO notifications VALUES("3","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=2","2019-05-04 06:12:22","no","no");
INSERT INTO notifications VALUES("4","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=1","2019-05-04 06:12:24","no","no");
INSERT INTO notifications VALUES("5","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=2","2019-05-04 07:10:35","no","no");
INSERT INTO notifications VALUES("6","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=2","2019-05-04 07:11:25","no","no");
INSERT INTO notifications VALUES("7","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=2","2019-05-04 07:11:46","no","no");
INSERT INTO notifications VALUES("8","vijina_aa","abhiram_das_1_2","Abhiram Das commented on your post","post.php?id=1","2019-05-04 07:12:07","no","no");
INSERT INTO notifications VALUES("9","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=1","2019-05-04 07:15:09","no","no");
INSERT INTO notifications VALUES("10","vijina_aa","abhiram_das_1_2","Abhiram Das liked your post","post.php?id=1","2019-05-04 07:18:01","no","no");



CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `added_by` varchar(60) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  `likes` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO posts VALUES("1","hai","vijina_aa","none","2019-05-03 15:06:14","no","no","0");
INSERT INTO posts VALUES("2","hai","vijina_aa","none","2019-05-03 15:06:25","no","no","1");
INSERT INTO posts VALUES("3","hi","abhiram_das","none","2019-06-08 07:44:13","no","no","0");



CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE `trends` (
  `title` varchar(60) NOT NULL,
  `hits` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO trends VALUES("Fdgsdhh","1");
INSERT INTO trends VALUES("Hee","1");
INSERT INTO trends VALUES("Guyzz","1");
INSERT INTO trends VALUES("Hai","1");
INSERT INTO trends VALUES("Hiii","1");
INSERT INTO trends VALUES("Hiiiiiiiiiiiiiiiiii","1");
INSERT INTO trends VALUES("Grn","1");
INSERT INTO trends VALUES("Ff","1");
INSERT INTO trends VALUES("Hi","8");
INSERT INTO trends VALUES("Hello","6");



CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signup_date` date NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `friend_array` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO users VALUES("4","Abhiram","Das","abhiram_das_1","Abhiramdas@gmail.com","97d4d1108d306a25e70b102f5cfe7efd","2019-03-15","assets/images/profile_pics/defaults/head_emerald.png","2","0","no",",vijina_aa,");
INSERT INTO users VALUES("5","Aa","Ss","aa_ss","Aa123456789@gmail.com","97d4d1108d306a25e70b102f5cfe7efd","2019-03-17","assets/images/profile_pics/defaults/head_emerald.png","2","0","no",",");
INSERT INTO users VALUES("12","Abhiram","Das","abhiram_das_1_2_3","Abhiramdas252526@gmail.com","419c57e5a487e62f3ef81c639a63f9ec","2019-05-13","assets/images/profile_pics/defaults/head_emerald.png","0","0","no",",");
INSERT INTO users VALUES("14","Vijina","Aa","vijina_aa","Vijinaanjus@gmail.com","5cd5c0a9c6ee5bdd033c2d8363f3745d","2019-05-13","assets/images/profile_pics/defaults/head_emerald.png","0","0","no",",");
INSERT INTO users VALUES("15","Nikhitha","Ja","nikhitha_ja","Nikhithaj1997@gmail.com","8abfb0df43eefc49ceaa0df35136649e","2019-05-13","assets/images/profile_pics/defaults/head_deep_blue.png","0","0","no",",");
INSERT INTO users VALUES("23","Abhiram","Das","abhiram_das","Abhiramdas2525@gmail.com","419c57e5a487e62f3ef81c639a63f9ec","2019-06-08","assets/images/profile_pics/defaults/head_deep_blue.png","2","0","no",",");

