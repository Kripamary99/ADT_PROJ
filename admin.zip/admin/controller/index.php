<?php
require('../config.php');

//usercount
$driverdetails = mysqli_query($con,"SELECT * FROM driverdetails");
$num_rows_driver = mysqli_num_rows($driverdetails);

//active count
$active_drivers = mysqli_query($con,"SELECT * FROM driverdetails WHERE status= 1");
$active_driver_count = mysqli_num_rows($active_drivers);

//code for todo
 $errors = "";

  // connect to database
  $db = mysqli_connect("localhost", "root", "", "project");

  // insert a quote if submit button is clicked
  if (isset($_POST['submit'])) {

    if (empty($_POST['task'])) {
      $errors = "You must fill in the task";
    }else{
      $task = $_POST['task'];
      $query = "INSERT INTO tasks (task) VALUES ('$task')";
      mysqli_query($db, $query);
      header('location: index.php');
    }
  } 

  // delete task
  if (isset($_GET['del_task'])) {
    $id = $_GET['del_task'];

    mysqli_query($db, "DELETE FROM tasks WHERE id=".$id);
    header('location: index.php');
  }

  // select all tasks if page is visited or refreshed
  $tasks = mysqli_query($db, "SELECT * FROM tasks");

?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Admin Dashboard</title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
  <link type="text/css" href="./assets/css/style.css" rel="stylesheet">
  <link type="text/css" href="./assets/css/from_style.css" rel="stylesheet">
  <script type="text/javascript">
    //auto expand textarea
    function adjust_textarea(h) {
        h.style.height = "20px";
        h.style.height = (h.scrollHeight)+"px";
    }
  </script>
</head>

<body>
  <!-- Sidenav -->
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <center><b> ADMIN</b></center>
      
     
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="./index.php">
                <img src="./assets/img/brand/blue.png">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        <!-- Form -->
        <form class="mt-4 mb-3 d-md-none">
          <div class="input-group input-group-rounded input-group-merge">
            <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Search" aria-label="Search">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <span class="fa fa-search"></span>
              </div>
            </div>
          </div>
        </form>
        <!-- Navigation -->
         <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/fare.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Fare
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/distance.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Distance
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/vehicle.php">
              <i class="ni ni-bullet-list-67 text-red"></i> Vehicle
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/view_bank.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Bank Details
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_documents.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Documents
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_driver_login.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Driver Login
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_request_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Request Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_rider_details.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Rider Details
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../pages/view_rider_login.php">
              <i class="ni ni-bullet-list-67 text-red"></i> View Rider login
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="mysqli.php">
              <i class="ni ni-key-25 text-info"></i>Database Backup
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="ni ni-circle-08 text-pink"></i> Logout
            </a>
          </li>
        </ul>
        
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="index.php">Dashboard</a>
        
    </nav>
    <!-- Header -->
    <center>
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Total Drivers</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo $num_rows_driver; ?></span>
                    </div>
                    <div class="col-auto" >
                      <div class="icon icon-shape bg-danger text-white rounded-circle shadow" >
                        <i class="fas fa-chart-bar"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Active Drivers</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo $active_driver_count; ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                        <i class="fas fa-chart-pie"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-lg-6">
              
            </div>
          </div>
        </div>
      </div>
    </div></center>
<?php
   
?>
<div class="heading">
    <h2 style="font-style: 'Hervetica';">ToDo List</h2>
  </div>


  <form method="post" action="index.php" class="input_form">
    <?php if (isset($errors)) { ?>
      <p><?php echo $errors; ?></p>
    <?php } ?>
    <input type="text" name="task" class="task_input">
    <button type="submit" name="submit" id="add_btn" class="add_btn">Add Task</button>
  </form>


  <table>
    <thead>
      <tr>
        <th>No.</th>
        <th>Tasks</th>
        <th style="width: 60px;">Action</th>
      </tr>
    </thead>

    <tbody>
      <?php $i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>
        <tr>
          <td> <?php echo $i; ?> </td>
          <td class="task"> <?php echo $row['task']; ?> </td>
          <td class="delete"> 
            <a href="index.php?del_task=<?php echo $row['id'] ?>">x</a> 
          </td>
        </tr>
      <?php $i++; } ?>  
    </tbody>
  </table>

    <!-- Page content -->
    
        
            
      
        
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2019 <a href="#" class="font-weight-bold ml-1" target="_blank"></a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link" target="_blank"></a>
              </li>
              
              
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.0.0"></script>
</body>

</html>