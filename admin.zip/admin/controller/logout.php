<?php 
require 'config.php';
session_start();
$username=$_SESSION['username'];
$query = mysqli_query($con, "DELETE FROM `active` WHERE username = '$username'");
session_destroy();
header("Location: ../../index.php");
 ?>